﻿using System;
using System.Collections.Generic;
using UnityEngine;
using CommNet.Occluders;

namespace BeamedPowerStandalone
{
    [KSPAddon(KSPAddon.Startup.SpaceCentre, true)]
    public class WirelessReceiver : PartModule
    {
        // Meant to be a module for spherical receivers (can recieve from multiple sources); coming soon™
    }
}
 