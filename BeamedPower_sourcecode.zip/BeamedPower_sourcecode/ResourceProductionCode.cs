// Work-in-progress (has lots of errors so not implemented)
// getting resource production in EC/s
this.vessel.GetConnectedResourceTotals(EChash, out double amount, out double max_amount, false);
// resource production if full
if (Convert.ToInt64(amount)==Convert.ToInt64(max_amount))
{
	int i = 0;
	double result = 0;
	this.vessel.GetConnectedResourceTotals(EChash, out double initialAmount, out double initialMaxAmount, false);
	if (i < 4)
	{
		int n = 1;
		if (Convert.ToInt64(initialAmount) == Convert.ToInt64(initialMaxAmount))
		{
			result += (Math.Pow(10, 3 - i) * n);
			this.part.RequestResource(EChash, -result * Time.fixedDeltaTime);
			this.vessel.GetConnectedResourceTotals(EChash, out double new_amount, out _, false);
			initialAmount = new_amount;
			n += 1;
		}
		result -= Math.Pow(10, 3 - i) * Time.fixedDeltaTime;
		this.part.RequestResource(EChash, Math.Pow(10, 3 - i) * Time.fixedDeltaTime);
		i += 1;
	}
	rate = result / Time.fixedDeltaTime;
}
// resource production if not full
else
{
	if (last_amount == -1)
	{
		last_amount = amount;
	}
	rate = (amount - last_amount) / Time.fixedDeltaTime + ECperSec;
	last_amount = amount;
}